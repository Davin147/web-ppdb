// Tombol daftar sekarang
const daftarButtons = document.querySelectorAll(".btn");

daftarButtons.forEach(button => {
  button.addEventListener("click", () => {
    alert("Terima kasih telah tertarik mendaftar di SMK Budi Bakti Ciwidey!");
  });
});

// Tombol pelajari lebih
const pelajariBtn = document.querySelector(".outline-btn");

pelajariBtn.addEventListener("click", () => {
  window.scrollTo({
    top: document.querySelector(".advantages").offsetTop,
    behavior: "smooth"
  });
});